<?php $__env->startSection('content'); ?>

					<!-- start: page -->
                    <div class="row">
                            <div class="col-lg-1"></div>
                                <div class="col-lg-10">
                                    <section class="panel">
                                        <header class="panel-heading">
                                            <div class="panel-actions">
                                                <a href="#" class="fa fa-caret-down"></a>
                                                <a href="#" class="fa fa-times"></a>
                                            </div>
                            
                                            <h2 class="panel-title">Detail Nasabah</h2>
                                        </header>
                                        <div class="panel-body">
													<div class="form-group">
														<label class="col-md-3 control-label" for="inputDisabled">No. Anggota</label>
														<div class="col-md-7">
															<input type="text" class="form-control" id="inputDisabled" type="text" placeholder="<?php echo e($nasabah -> no_anggota); ?>" disabled="">
														</div>
													</div>

													<div class="form-group">
														<label class="col-md-3 control-label" for="inputDisabled">Nama Nasabah</label>
														<div class="col-md-7">
															<input type="text" class="form-control" id="inputDisabled" type="text" placeholder="<?php echo e($nasabah -> nama); ?>" disabled="">
														</div>
													</div>

													<div class="form-group">
														<label class="col-md-3 control-label" for="inputDisabled">Alamat</label>
														<div class="col-md-7">
															<input type="text" class="form-control" id="inputDisabled" type="text" placeholder="<?php echo e($nasabah -> alamat); ?>" disabled="">
														</div>
													</div>

													<div class="form-group">
														<label class="col-md-3 control-label" for="inputDisabled">No. Telepon</label>
														<div class="col-md-7">
															<input type="text" class="form-control" id="inputDisabled" type="text" placeholder="<?php echo e($nasabah -> telepon); ?>" disabled="">
														</div>
													</div>


													<div class="form-group">
														<label class="col-md-3 control-label" for="inputDisabled">No Identitas</label>
														<div class="col-md-7">
															<input type="text" class="form-control" id="inputDisabled" type="text" placeholder="<?php echo e($nasabah -> noktp); ?>" disabled="">
														</div>
													</div>

													<div class="form-group">
														<label class="col-md-3 control-label" for="inputDisabled">Jenis Kelamin</label>
														<div class="col-md-7">
															<input type="text" class="form-control" id="inputDisabled" type="text" placeholder="<?php echo e($nasabah -> kelamin); ?>" disabled="">
														</div>
													</div>

                                        </div>
                                    </section>
                                </div>
						</div>
						
					<div class="row">
						<div class="col-md-1"></div>
						<div class="col-md-5">
							<section class="panel">
								<header class="panel-heading">
									<div class="panel-actions">
										<a href="#" class="fa fa-caret-down"></a>
										<a href="#" class="fa fa-times"></a>
									</div>
									<h2 class="panel-title">Total Saldo</h2>
								</header>
								<div class="panel-body">
								<h2>Rp.<?php echo e(number_format($totalSaldo)); ?></h2>
								</div>
							</section>
						</div>

						<div class="col-md-5">
							<section class="panel">
								<header class="panel-heading">
									<div class="panel-actions">
										<a href="#" class="fa fa-caret-down"></a>
										<a href="#" class="fa fa-times"></a>
									</div>

									<h2 class="panel-title">Bunga Bulan Depan*</h2>
								</header>
								<div class="panel-body">
									<h2>Rp.<?php echo e(number_format($bungaDepan)); ?></h2>
								</div>
							</section>
						</div>

						
					</div>

					<div class="row">
						<div class="col-md-1"></div>
						<div class="col-md-10">
							<section class="panel">
								<header class="panel-heading">
									<div class="panel-actions">
										<a href="#" class="fa fa-caret-down"></a>
										<a href="#" class="fa fa-times"></a>
									</div>
									<h2 class="panel-title">Transaksi Simpanan</h2>
									</header>
									<div class="panel-body">
										<table class="table table-bordered table-striped mb-none" id="datatable-default">
											<thead>
												<tr>
												<th>No</th>
												<th>No Anggota</th>
												<th>Tanggal</th>
												<th>Tarik</th>
												<th>Simpan</th>
												<th>Bunga</th>
												<th>Saldo</th>
												<th>Pegawai</th>
											</tr>
										</thead>
										<tbody>
											<?php
												$saldo = 0;
											?>
											<?php $__currentLoopData = $transaksis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaksi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<tr>
												<td><?php echo e($loop->iteration); ?></td>
												<td><?php echo e($transaksi->no_anggota); ?></td>
												<td><?php echo e($transaksi->tanggal); ?></td>
												<?php if($transaksi->jenis_transaksi == 1): ?>
												<td></td>
												<td>Rp.<?php echo e(number_format($transaksi->nominal_transaksi)); ?></td>
												<td></td>
												<td>Rp.<?php echo e(number_format($saldo = ($saldo + $transaksi->nominal_transaksi))); ?></td>
												<?php elseif($transaksi->jenis_transaksi == 2): ?>
												<td>Rp.<?php echo e(number_format($transaksi->nominal_transaksi)); ?></td>
												<td></td>
												<td></td>
												<td>Rp.<?php echo e(number_format($saldo = ($saldo - $transaksi->nominal_transaksi))); ?></td>
												<?php elseif($transaksi->jenis_transaksi == 3): ?>
												<td></td>
												<td></td>
												<td>Rp.<?php echo e(number_format($transaksi->nominal_transaksi)); ?></td>
												<td>Rp.<?php echo e(number_format($saldo = ($saldo + $transaksi->nominal_transaksi))); ?></td>
												<?php endif; ?>
												<td><?php echo e($transaksi->nama_pegawai); ?></td>
											</tr>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</tbody>
										</table>
									</div>

					</div>
						
					<!-- end: page -->
				</section>
			</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>