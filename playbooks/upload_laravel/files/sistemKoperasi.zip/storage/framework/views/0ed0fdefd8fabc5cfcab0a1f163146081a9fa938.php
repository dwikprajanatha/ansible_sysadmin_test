<?php $__env->startSection('css'); ?>

		<!-- Specific Page Vendor CSS -->
		<link rel="stylesheet" href="assets/vendor/morris/morris.css" />

<?php $__env->stopSection(); ?>

<?php $__env->startSection('header-nav','Yearly Report'); ?>

<?php $__env->startSection('content'); ?>

								<div class="row">
									<div class="col-md-8">
										<h3 class="mt-lg">Laporan Laju Tabungan</h3>
										<p class="mb-lg">Laporan Dari Bulan ke-1 Hingga Bulan ke-12 </p>
									</div>
									<div class="col-md-12 col-xl-6">
										<section class="panel panel-featured panel-featured-primary">
											<div class="panel-body">
												<div class="chart chart-sm" id="flotWidgetsSales1"></div>
												<script>

													var flotWidgetsSales1Data = [{
													    data: [

                                                            <?php $__currentLoopData = array_combine($months,$reports); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $month => $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            ["<?php echo e($month); ?>", "<?php echo e($report->total_trx); ?>"],
                                                        
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
													    ],
													    color: "#0088cc"
													}];
						
												</script>
												<hr class="solid short mt-lg">
												<div class="row">
													<div class="col-md-4">
														<div class="h4 text-bold mb-none mt-lg">Rp. <?php echo e(number_format($total_saldo)); ?></div>
														<p class="text-xs text-muted mb-none">Total Saldo Selama Periode</p>
													</div>
													<div class="col-md-4">
														<div class="h4 text-bold mb-none mt-lg">Rp. <?php echo e(number_format($avg_total)); ?> </div>
														<p class="text-xs text-muted mb-none">Rata-rata per Bulan</p>
													</div>
													<div class="col-md-4">
														<?php if($selisih < 0): ?>
														<div class="h4 text-bold mb-none mt-lg"><i class="fa fa-arrow-down"></i> <?php echo e($selisih); ?></div>
														<p class="text-xs text-muted mb-none">Selisih dari Bulan Lalu</p>
														<?php else: ?>
														<div class="h4 text-bold mb-none mt-lg"><i class="fa fa-arrow-up"></i> <?php echo e($selisih); ?></div>
														<p class="text-xs text-muted mb-none">Selisih dari Bulan Lalu</p>
														<?php endif; ?>
													</div>
												</div>
											</div>
										</section>
									</div>
								</div>


<div class="row">

<div class="col-md-6">
    <section class="panel panel-featured-left panel-featured-quartenary">
        <div class="panel-body">
            <div class="widget-summary">
                <div class="widget-summary-col widget-summary-col-icon">
                    <div class="summary-icon bg-quartenary">
                        <i class="fa fa-user"></i>
                    </div>
                </div>
                <div class="widget-summary-col">
                    <div class="summary">
                        <h4 class="title">Perkembangan Jumlah Nasabah</h4>
                        <div class="info">
                            <strong class="amount"><?php echo e($nasabah_sekarang); ?></strong>
                            <?php if($selisih_nasabah < 0): ?>
                            <span class="text-primary">(<i class="fa fa-arrow-down"></i> <?php echo e($selisih_nasabah); ?>)</span>
                            <?php else: ?>
                            <span class="text-primary">(<i class="fa fa-arrow-up"></i> <?php echo e($selisih_nasabah); ?>)</span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="summary-footer">
                        <a class="text-muted text-uppercase">(Sesuai Periode)</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>


<div class="col-md-6">
    <section class="panel panel-featured-left panel-featured-tertiary">
        <div class="panel-body">
            <div class="widget-summary">
                <div class="widget-summary-col widget-summary-col-icon">
                    <div class="summary-icon bg-tertiary">
                        <i class="fa fa-money"></i>
                    </div>
                </div>
                <div class="widget-summary-col">
                    <div class="summary">
                        <h4 class="title">Total Uang</h4>
                        <div class="info">
                            <strong class="amount">Rp. <?php echo e(number_format($total_uang)); ?> </strong>
                        </div>
                    </div>
                    <div class="summary-footer">
                        <a class="text-muted text-uppercase">(Total Keseluruhan)</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>


</div>



<div class="row">
    <div class="col-md-12">
        <section class="panel">
            <header class="panel-heading">
                <div class="panel-actions">
                    <a href="#" class="fa fa-caret-down"></a>
                    <a href="#" class="fa fa-times"></a>
                </div>
                <h2 class="panel-title">List Simpanan Satu Tahun</h2>
            </header>
                <div class="panel-body">
                    <table class="table table-bordered table-striped mb-none" id="datatable-default">
                        <thead>
                            <tr>
                            <th>No</th>
                            <th>No Anggota</th>
                            <th>Nama Nasabah</th>
                            <th>Tanggal</th>
                            <th>Jenis Transaksi</th>
                            <th>Nominal</th>
                            <th>Pegawai</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $simpanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Simpan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($Simpan -> no_anggota); ?></a></td>
                            <td><?php echo e($Simpan -> nama); ?></td>
                            <td><?php echo e($Simpan -> tanggal); ?></td>
                            <td><?php echo e($Simpan -> transaksi); ?></td>
                            <td>Rp.<?php echo e(number_format($Simpan -> nominal_transaksi)); ?></td>
                            <td><?php echo e($Simpan -> nama_pegawai); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    </table>
                </div>
        </section>
    </div>
</div>






<?php $__env->stopSection(); ?>


<?php $__env->startSection('javascript'); ?>

		<!-- Specific Page Vendor -->
		<script src="<?php echo e(asset('assets/vendor/jquery-ui/js/jquery-ui-1.10.4.custom.js')); ?>"></script>
		<script src="<?php echo e(asset('assets/vendor/jquery-ui-touch-punch/jquery.ui.touch-punch.js')); ?>"></script>
		<script src="<?php echo e(asset('assets/vendor/jquery-appear/jquery.appear.js')); ?>"></script>
		<script src="<?php echo e(asset('assets/vendor/jquery-easypiechart/jquery.easypiechart.js')); ?>"></script>
		<script src="<?php echo e(asset('assets/vendor/flot/jquery.flot.js')); ?>"></script>
		<script src="<?php echo e(asset('assets/vendor/flot-tooltip/jquery.flot.tooltip.js')); ?>"></script>
		<script src="<?php echo e(asset('assets/vendor/flot/jquery.flot.pie.js')); ?>"></script>
		<script src="<?php echo e(asset('assets/vendor/flot/jquery.flot.categories.js')); ?>"></script>
		<script src="<?php echo e(asset('assets/vendor/flot/jquery.flot.resize.js')); ?>"></script>
		<script src="<?php echo e(asset('assets/vendor/jquery-sparkline/jquery.sparkline.js')); ?>"></script>
		<script src="<?php echo e(asset('assets/vendor/raphael/raphael.js')); ?>"></script>
		<script src="<?php echo e(asset('assets/vendor/morris/morris.js')); ?>"></script>
		<script src="<?php echo e(asset('assets/vendor/owl-carousel/owl.carousel.js')); ?>"></script>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('javascript'); ?>
    <script>
        /*
		Flot
		*/
		var plot = $.plot('#flotWidgetsSales1', flotWidgetsSales1Data, {
			series: {
				lines: {
					show: true,
					lineWidth: 2
				},
				points: {
					show: true
				},
				shadowSize: 0
			},
			grid: {
				hoverable: true,
				clickable: true,
				borderColor: 'transparent',
				borderWidth: 1,
				labelMargin: 15,
				backgroundColor: 'transparent'
			},
			yaxis: {
				min: 0,
				color: 'transparent'
			},
			xaxis: {
				mode: 'categories',
				color: 'transparent'
			},
			legend: {
				show: false
			},
			tooltip: true,
			tooltipOpts: {
				content: '%y',
				shifts: {
					x: -30,
					y: 25
				},
				defaultTheme: false
			}
		});
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('template.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>