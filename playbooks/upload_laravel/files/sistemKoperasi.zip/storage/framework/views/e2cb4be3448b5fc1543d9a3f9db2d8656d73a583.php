<?php $__env->startSection('header-nav','List Bunga'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
    <?php if($errors->any()): ?>
		<div class="alert alert-danger">
		    <ul>
			<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			    <li><?php echo e($error); ?></li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</ul>
		</div>
	<?php endif; ?>
        <section class="panel">
            <header class="panel-heading">
                <div class="panel-actions">
                    <a href="#" class="fa fa-caret-down"></a>
                    <a href="#" class="fa fa-times"></a>
                </div>
                <h2 class="panel-title">List Transaksi</h2>
            </header>
            <div class="panel-body">
                <table class="table table-bordered table-striped mb-none" id="datatable-default">
                <a href="<?php echo e(route('simpanan.create')); ?>"><button type="button" class="mb-xs mt-xs mr-xs btn btn-success">Tambah Bunga</button></a>
                <a href="<?php echo e(url('bunga/hitung_bunga')); ?>"><button type="button" class="mb-xs mt-xs mr-xs btn btn-warning">Hitung Bunga</button></a>
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Bulan</th>
                            <th>Tahun</th>
                            <th>Tanggal</th>
                            <th>Persentase Bunga</th>
                            <th>Pegawai</th>
                        </tr>
                    </thead>
                    <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($data->trx_bulan); ?></td>
                        <td><?php echo e($data->trx_tahun); ?></td>
                        <td><?php echo e($data->tanggal_proses); ?></td>
                        <td><?php echo e($data->persentase_bunga); ?>%</td>
                        <td><?php echo e($data->nama_pegawai); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </section>
    </div>
</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>