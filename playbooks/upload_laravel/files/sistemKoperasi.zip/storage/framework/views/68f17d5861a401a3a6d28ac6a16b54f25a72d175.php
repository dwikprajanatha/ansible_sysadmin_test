				<!-- start: sidebar -->
				<aside id="sidebar-left" class="sidebar-left">
				
					<div class="sidebar-header">
						<div class="sidebar-title">
							Navigation
						</div>
						<div class="sidebar-toggle hidden-xs" data-toggle-class="sidebar-left-collapsed" data-target="html" data-fire-event="sidebar-left-toggle">
							<i class="fa fa-bars" aria-label="Toggle sidebar"></i>
						</div>
					</div>
				
					<div class="nano">
						<div class="nano-content">
							<nav id="menu" class="nav-main" role="navigation">
								<ul class="nav nav-main">
									<li class="nav-active">
										<a href="index.html">
											<i class="fa fa-home" aria-hidden="true"></i>
											<span>Dashboard</span>
										</a>
									</li>

									<li class="nav-parent">
										<a>
											<i class="fa fa-copy" aria-hidden="true"></i>
											<span>Transaksi</span>
										</a>
										<ul class="nav nav-children">
											<li>
												<a href="#">
													 Simpan
												</a>
                                            </li>
                                            <li>
												<a href="#">
													 Pinjam
												</a>
                                            </li>
                                            <li>
												<a href="#">
													 Pengembalian
												</a>
                                            </li>
                                            <li>
												<a href="#">
													 Penarikan
												</a>
											</li>
											<li>
												<a href="#">
													 Lihat Transaksi
												</a>
											</li>
										</ul>
									</li>
									<li>
										<a href="#">
											<i class="fa fa-group" aria-hidden="true"></i>
											<span>Data Nasabah</span>
										</a>
									</li>
								</ul>
							</nav>
				
							
				
					</div>
				
				</aside>
                <!-- end: sidebar -->
                
                <!-- start: navigation header -->
                <section role="main" class="content-body">
					<header class="page-header">
						<h2>Dashboard</h2>
					
						<div class="right-wrapper pull-right">
							<ol class="breadcrumbs">
								<li>
									<a href="index.html">
										<i class="fa fa-home"></i>
									</a>
								</li>
								<li><span>Dashboard</span></li>
							</ol>
					
							<a class="sidebar-right-toggle" data-open="sidebar-right"><i class="fa fa-chevron-left"></i></a>
						</div>
                    </header>
                    <!-- end: navigation header -->