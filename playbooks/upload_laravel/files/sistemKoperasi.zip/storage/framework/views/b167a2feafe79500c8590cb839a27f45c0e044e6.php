<?php $__env->startSection('header-nav','List Pegawai'); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
<div class="col-md-12">
   <section class="panel">
      <header class="panel-heading">
         <div class="panel-actions">
            <a href="#" class="fa fa-caret-down"></a>
            <a href="#" class="fa fa-times"></a>
         </div>
         <h2 class="panel-title">Pegawai</h2>
      </header>
      <div class="panel-body">
         <div class="table-responsive">
            <table class="table table-striped mb-none">
               <thead>
                  <tr>
                     <th>No</th>
                     <th>NIK</th>
                     <th>Nama</th>
                     <th>Jabatan</th>
                  </tr>
               </thead>
               <tbody>
                  <?php $__currentLoopData = $Users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $User): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                     <td><?php echo e($loop->iteration); ?></td>
                     <td><?php echo e($User->nik); ?></td>
                     <td><?php echo e($User->nama_pegawai); ?></td>
                     <?php if($User->user_role == 1): ?>
                     <td>Admin</td>
                     <?php elseif($User->user_role == 2): ?>
                     <td>Pegawai Simpanan</td>
                     <?php else: ?>
                     <td>Pegawai Pinjaman</td>
                     <?php endif; ?>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </tbody>
            </table>
         </div>
         <a href="<?php echo e(url('pegawai/create')); ?>"><button type="button" class="mb-xs mt-xs mr-xs btn btn-primary">Tambah</button></a>
      </div>
   </section>
</div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>