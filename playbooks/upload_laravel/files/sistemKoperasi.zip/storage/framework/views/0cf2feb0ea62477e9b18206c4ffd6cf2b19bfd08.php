<?php $__env->startSection('css'); ?>
   
		<!-- Specific Page Vendor CSS -->
		<link rel="stylesheet" href="<?php echo e(asset('assets/vendor/select2/select2.css')); ?>" />
		<link rel="stylesheet" href="<?php echo e(asset('assets/vendor/jquery-datatables-bs3/assets/css/datatables.css')); ?>" />


<?php $__env->stopSection(); ?>

<?php $__env->startSection('header-nav','List Nasabah'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
<div class="col-md-14">
   <section class="panel">
      <header class="panel-heading">
         <div class="panel-actions">
            <a href="#" class="fa fa-caret-down"></a>
            <a href="#" class="fa fa-times"></a>
         </div>
         <h2 class="panel-title">List Nasabah</h2>
							</header>
							<div class="panel-body">
								<table class="table table-bordered table-striped mb-none" id="datatable-default">
									<thead>
										<tr>
											<th style="text-align:center">No</th>
											<th style="text-align:center">No. Anggota</th>
											<th style="text-align:center">Nama</th>
											<th style="text-align:center">Alamat</th>
                                            <th style="text-align:center">Telepon</th>
                                            <th style="text-align:center">No Identitas</th>
                                            <th style="text-align:center">Jenis Kelamin</th>
                                            <th style="text-align:center">Pembuat</th>
                                            <th style="text-align:center">Status Aktif</th>
                                            <th style="text-align:center">Action</th>
										</tr>
									</thead>
                                    <tbody>
                                        <?php 
                                                $i = 1;
                                        ?>
                                        <?php $__currentLoopData = $Nasabahs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Nasabah): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($i++); ?></td>
                                            <td><a href="<?php echo e(route('nasabah.show',[$Nasabah->id])); ?>"><?php echo e($Nasabah -> no_anggota); ?></a></td>
                                            <td><?php echo e($Nasabah -> nama); ?></td>
                                            <td><?php echo e($Nasabah -> alamat); ?></td>
                                            <td><?php echo e($Nasabah -> telepon); ?></td>
                                            <td><?php echo e($Nasabah -> noktp); ?></td>
                                            <td><?php echo e($Nasabah -> kelamin); ?></td>
                                            <td><?php echo e($Nasabah -> nama_pegawai); ?></td>
                                            
                                            <?php if( $Nasabah->status_aktif != 1): ?>
                                            <td>Tidak Aktif</td>
                                            <?php else: ?>
                                            <td>Aktif</td>
                                            <?php endif; ?>
                                            <td>
                                                <table>
                                                    <tr>
                                                        <td>
                                                            <form action="<?php echo e(route('nasabah.destroy', [$Nasabah->id])); ?>" method="POST">
                                                                 <?php echo csrf_field(); ?>
                                                                <?php echo e(method_field('DELETE')); ?>

                                                                <button type="submit" class="mb-xs mt-xs mr-xs btn btn-danger"><i class="fa fa-times"></i></button>
                                                            </form>
                                                        </td>
                                                        <td><a href="<?php echo e(route('nasabah.edit', [$Nasabah->id])); ?>"><button type="button" class="mb-xs mt-xs mr-xs btn btn-warning"><i class="fa fa-pencil"></i></button></a></td>
                                                    </tr>
                                                </table>
                                                

                                            </td>
                                            
                                        </tr>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                    </table>
                                </div>
                            </div>
                        </section>
                        </div>
                        </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>

        <!-- Specific Page Vendor -->
        <script src="<?php echo e(asset('assets/vendor/select2/select2.js')); ?>"></script>
		<script src="<?php echo e(asset('assets/vendor/jquery-datatables/media/js/jquery.dataTables.js')); ?>"></script>
		<script src="<?php echo e(asset('assets/vendor/jquery-datatables/extras/TableTools/js/dataTables.tableTools.min.js')); ?>"></script>
		<script src="<?php echo e(asset('assets/vendor/jquery-datatables-bs3/assets/js/datatables.js')); ?>"></script>

<?php $__env->stopSection(); ?>



<?php $__env->startPush('javascript'); ?>
    <script>
        $("#datatable-default").dataTable();
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('template.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>