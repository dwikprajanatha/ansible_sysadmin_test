<?php $__env->startSection('header-nav','Form Simpanan'); ?>

<?php $__env->startSection('content'); ?>

					<!-- start: page -->
						<div class="row">
							<div class="col-xs-12">
							<?php if($errors->any()): ?>
							<div class="alert alert-danger">
								<ul>
									<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<li><?php echo e($error); ?></li>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</ul>
							</div>
							<?php endif; ?>
								<section class="panel">
									<header class="panel-heading">
										<div class="panel-actions">
										</div>
						
										<h2 class="panel-title">Form Transaksi</h2>
									</header>
									<div class="panel-body">
										<form class="form-horizontal form-bordered" method="POST" action="<?php echo e(url('simpan-cari')); ?>">
											<?php echo csrf_field(); ?>
											<div class="form-group">
													<label class="col-md-3 control-label">No. Anggota</label>
													<div class="col-md-6">
														<div class="input-group input-search">
															<input type="text" class="form-control" name="no_anggota" id="q" placeholder="Cari No Anggota.." autocomplete="off">
															<span class="input-group-btn">
																<button class="btn btn-default" type="submit"><i class="fa fa-search"></i></button>
															</span>
														</div>
													</div>
												</div>
											</div>
						                                           									
										</form>
									</div>
								</section>
								
							</div>
							
						</div>
						
						
						
					<!-- end: page -->
				</section>
			</div>



	

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>