<?php $__env->startSection('css'); ?>
   
   <!-- Specific Page Vendor CSS -->
   <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/select2/select2.css')); ?>" />
   <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/jquery-datatables-bs3/assets/css/datatables.css')); ?>" />


<?php $__env->stopSection(); ?>

<?php $__env->startSection('header-nav','List Transaksi Simpan'); ?>

<?php $__env->startSection('content'); ?>

                           
<div class="row">
<div class="col-md-12">
   <section class="panel">
      <header class="panel-heading">
         <div class="panel-actions">
            <a href="#" class="fa fa-caret-down"></a>
            <a href="#" class="fa fa-times"></a>
         </div>
         <h2 class="panel-title">List Transaksi</h2>
							</header>
		<div class="panel-body">
			<table class="table table-bordered table-striped mb-none" id="datatable-default">
				<thead>
				    <tr>
                     <th>No</th>
                     <th>No Anggota</th>
                     <th>Nama Nasabah</th>
					 <th>Tanggal</th>
					 <th>Jenis Transaksi</th>
					 <th>Nominal</th>
                     <th>Pegawai</th>
                  </tr>
               </thead>
               <tbody>
                  <?php $__currentLoopData = $Simpans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Simpan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                     <td><?php echo e($loop->iteration); ?></td>
                     <td><a href="<?php echo e(route('nasabah.show',[$Simpan->anggota_id])); ?>"><?php echo e($Simpan -> no_anggota); ?></a></td>
                     <td><?php echo e($Simpan -> nama); ?></td>
                     <td><?php echo e($Simpan -> tanggal); ?></td>
                     <td><?php echo e($Simpan -> transaksi); ?></td>
                     <td>Rp.<?php echo e(number_format($Simpan -> nominal_transaksi)); ?></td>
                     <td><?php echo e($Simpan -> nama_pegawai); ?></td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </tbody>
            </table>
         </div>
      </div>
   </section>
</div>
</div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>

<!-- Specific Page Vendor -->
<script src="<?php echo e(asset('assets/vendor/select2/select2.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/jquery-datatables/media/js/jquery.dataTables.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/jquery-datatables/extras/TableTools/js/dataTables.tableTools.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/jquery-datatables-bs3/assets/js/datatables.js')); ?>"></script>

<?php $__env->stopSection(); ?>




<?php echo $__env->make('template.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>