<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/daftar', function (){
    return view('daftar');
});

Route::get('/','AdminController@index');

Route::resource('simpan','ControllerSimpan');

Route::get('/simpan-cari','ControllerSimpan@check');
Route::post('/simpan-cari','ControllerSimpan@checkData');

// Route::get('simpan/cari', function(){
//     return view('simpan');

// });

Route::resource('nasabah','NasabahController');

Route::resource('pegawai','PegawaiController');

Route::resource('bunga/simpanan','BungaController');

Route::get('bunga/hitung_bunga','BungaController@hitungBunga');

Route::get('report/weekly','ReportController@weekly');
Route::post('report/weekly/cari','ReportController@weekly_search')->name('weekly.cari');

Route::get('report/monthly','ReportController@monthly');
Route::post('report/monthly/cari','ReportController@monthly_search')->name('monthly.cari');

Route::get('report/yearly','ReportController@yearly');
Route::post('report/yearly/cari','ReportController@yearly_search')->name('yearly.cari');


Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
