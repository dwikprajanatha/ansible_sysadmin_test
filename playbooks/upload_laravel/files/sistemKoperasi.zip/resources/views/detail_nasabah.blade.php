@extends('template.app')

@section('content')

					<!-- start: page -->
                    <div class="row">
                            <div class="col-lg-1"></div>
                                <div class="col-lg-10">
                                    <section class="panel">
                                        <header class="panel-heading">
                                            <div class="panel-actions">
                                                <a href="#" class="fa fa-caret-down"></a>
                                                <a href="#" class="fa fa-times"></a>
                                            </div>
                            
                                            <h2 class="panel-title">Detail Nasabah</h2>
                                        </header>
                                        <div class="panel-body">
													<div class="form-group">
														<label class="col-md-3 control-label" for="inputDisabled">No. Anggota</label>
														<div class="col-md-7">
															<input type="text" class="form-control" id="inputDisabled" type="text" placeholder="{{$nasabah -> no_anggota}}" disabled="">
														</div>
													</div>

													<div class="form-group">
														<label class="col-md-3 control-label" for="inputDisabled">Nama Nasabah</label>
														<div class="col-md-7">
															<input type="text" class="form-control" id="inputDisabled" type="text" placeholder="{{$nasabah -> nama}}" disabled="">
														</div>
													</div>

													<div class="form-group">
														<label class="col-md-3 control-label" for="inputDisabled">Alamat</label>
														<div class="col-md-7">
															<input type="text" class="form-control" id="inputDisabled" type="text" placeholder="{{$nasabah -> alamat}}" disabled="">
														</div>
													</div>

													<div class="form-group">
														<label class="col-md-3 control-label" for="inputDisabled">No. Telepon</label>
														<div class="col-md-7">
															<input type="text" class="form-control" id="inputDisabled" type="text" placeholder="{{$nasabah -> telepon}}" disabled="">
														</div>
													</div>


													<div class="form-group">
														<label class="col-md-3 control-label" for="inputDisabled">No Identitas</label>
														<div class="col-md-7">
															<input type="text" class="form-control" id="inputDisabled" type="text" placeholder="{{$nasabah -> noktp}}" disabled="">
														</div>
													</div>

													<div class="form-group">
														<label class="col-md-3 control-label" for="inputDisabled">Jenis Kelamin</label>
														<div class="col-md-7">
															<input type="text" class="form-control" id="inputDisabled" type="text" placeholder="{{$nasabah -> kelamin}}" disabled="">
														</div>
													</div>

                                        </div>
                                    </section>
                                </div>
						</div>
						
					<div class="row">
						<div class="col-md-1"></div>
						<div class="col-md-5">
							<section class="panel">
								<header class="panel-heading">
									<div class="panel-actions">
										<a href="#" class="fa fa-caret-down"></a>
										<a href="#" class="fa fa-times"></a>
									</div>
									<h2 class="panel-title">Total Saldo</h2>
								</header>
								<div class="panel-body">
								<h2>Rp.{{ number_format($totalSaldo) }}</h2>
								</div>
							</section>
						</div>

						<div class="col-md-5">
							<section class="panel">
								<header class="panel-heading">
									<div class="panel-actions">
										<a href="#" class="fa fa-caret-down"></a>
										<a href="#" class="fa fa-times"></a>
									</div>

									<h2 class="panel-title">Bunga Bulan Depan*</h2>
								</header>
								<div class="panel-body">
									<h2>Rp.{{ number_format($bungaDepan) }}</h2>
								</div>
							</section>
						</div>

						
					</div>

					<div class="row">
						<div class="col-md-1"></div>
						<div class="col-md-10">
							<section class="panel">
								<header class="panel-heading">
									<div class="panel-actions">
										<a href="#" class="fa fa-caret-down"></a>
										<a href="#" class="fa fa-times"></a>
									</div>
									<h2 class="panel-title">Transaksi Simpanan</h2>
									</header>
									<div class="panel-body">
										<table class="table table-bordered table-striped mb-none" id="datatable-default">
											<thead>
												<tr>
												<th>No</th>
												<th>No Anggota</th>
												<th>Tanggal</th>
												<th>Tarik</th>
												<th>Simpan</th>
												<th>Bunga</th>
												<th>Saldo</th>
												<th>Pegawai</th>
											</tr>
										</thead>
										<tbody>
											@php
												$saldo = 0;
											@endphp
											@foreach($transaksis as $transaksi)
											<tr>
												<td>{{ $loop->iteration }}</td>
												<td>{{ $transaksi->no_anggota }}</td>
												<td>{{ $transaksi->tanggal }}</td>
												@if($transaksi->jenis_transaksi == 1)
												<td></td>
												<td>Rp.{{ number_format($transaksi->nominal_transaksi) }}</td>
												<td></td>
												<td>Rp.{{ number_format($saldo = ($saldo + $transaksi->nominal_transaksi)) }}</td>
												@elseif($transaksi->jenis_transaksi == 2)
												<td>Rp.{{ number_format($transaksi->nominal_transaksi) }}</td>
												<td></td>
												<td></td>
												<td>Rp.{{ number_format($saldo = ($saldo - $transaksi->nominal_transaksi)) }}</td>
												@elseif($transaksi->jenis_transaksi == 3)
												<td></td>
												<td></td>
												<td>Rp.{{ number_format($transaksi->nominal_transaksi) }}</td>
												<td>Rp.{{ number_format($saldo = ($saldo + $transaksi->nominal_transaksi)) }}</td>
												@endif
												<td>{{$transaksi->nama_pegawai}}</td>
											</tr>
											@endforeach
										</tbody>
										</table>
									</div>

					</div>
						
					<!-- end: page -->
				</section>
			</div>



@endsection