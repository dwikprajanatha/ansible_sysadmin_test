@extends('template.app')

@section('css')

   <!-- Specific Page Vendor CSS -->
   <link rel="stylesheet" href="{{asset('assets/vendor/select2/select2.css')}}" />
   <link rel="stylesheet" href="{{asset('assets/vendor/jquery-datatables-bs3/assets/css/datatables.css')}}" />

@endsection

@section('header-nav','Form Simpanan')

@section('content')

					<!-- start: page -->
                    <div class="row">
                            <div class="col-lg-1"></div>
                                <div class="col-lg-10">
                                    <section class="panel">
                                        <header class="panel-heading">
                                            <div class="panel-actions">
                                                <a href="#" class="fa fa-caret-down"></a>
                                                <a href="#" class="fa fa-times"></a>
                                            </div>
                            
                                            <h2 class="panel-title">Form Simpanan</h2>
                                        </header>
                                        <div class="panel-body">
                                            <form class="form-horizontal form-bordered" method="POST" action="simpan">
											@csrf
													<div class="form-group">
														<input type="hidden" name="id_nasabah" value="{{$dataAnggotas -> id}}">
														<label class="col-md-3 control-label" for="inputDisabled">No. Anggota</label>
														<div class="col-md-7">
															<input type="text" class="form-control" id="inputDisabled" type="text" placeholder="{{$dataAnggotas -> no_anggota}}" disabled="">
														</div>
													</div>

													<div class="form-group">
														<label class="col-md-3 control-label" for="inputDisabled">Nama Nasabah</label>
														<div class="col-md-7">
															<input type="text" class="form-control" id="inputDisabled" type="text" placeholder="{{$dataAnggotas -> nama}}" disabled="">
														</div>
													</div>

													<div class="form-group">
														<label class="col-md-3 control-label" for="inputDisabled">Alamat</label>
														<div class="col-md-7">
															<input type="text" class="form-control" id="inputDisabled" type="text" placeholder="{{$dataAnggotas -> alamat}}" disabled="">
														</div>
													</div>

													<div class="form-group">
														<label class="col-md-3 control-label" for="inputDisabled">No. Telepon</label>
														<div class="col-md-7">
															<input type="text" class="form-control" id="inputDisabled" type="text" placeholder="{{$dataAnggotas -> telepon}}" disabled="">
														</div>
													</div>


													<div class="form-group">
														<label class="col-md-3 control-label" for="inputDisabled">No Identitas</label>
														<div class="col-md-7">
															<input type="text" class="form-control" id="inputDisabled" type="text" placeholder="{{$dataAnggotas -> noktp}}" disabled="">
														</div>
													</div>

													<div class="form-group">
														<label class="col-md-3 control-label" for="inputDisabled">Jenis Kelamin</label>
														<div class="col-md-7">
															<input type="text" class="form-control" id="inputDisabled" type="text" placeholder="{{$dataAnggotas -> kelamin}}" disabled="">
														</div>
													</div>


													<div class="col-md-12">

															<div class="form-group">

																<label class="control-label col-md-4" style="padding-top:0px"></label>
																
																<div class="radio-custom radio-primary" style="display:inline; margin-left:30px; padding-left:25px;">
																			<input type="radio" id="radioExample1" name="jenisTransaksi" required="" value="1">
																			<label for="radioExample1">Simpan</label>
																</div>
																<div class="radio-custom radio-primary" style="display:inline; margin-left:30px; padding-left:25px">
																			<input type="radio" id="radioExample2" name="jenisTransaksi" value="2"> 
																			<label for="radioExample2">Tarik</label>
																</div>
															</div>
													</div>
				
													<div class="form-group" style="margin-top:70px">

														<label class="col-md-3 control-label">Nominal</label>
														<div class="col-md-7">
															<div class="input-group mb-md">
																<span class="input-group-addon btn-success">Rp</span>
																<input type="text" name="nominal" class="form-control" placeholder="" required="">
															</div>		
														</div>    
													</div>
												
												
														<button type="submit" class="mb-xs mt-xs mr-xs btn btn-primary" style="margin-left:45%">Submit</button>
                                            </form>
                                        </div>
                                    </section>
                                </div>
						</div>
						
					<div class="row">
						<div class="col-md-1"></div>
						<div class="col-md-5">
							<section class="panel">
								<header class="panel-heading">
									<div class="panel-actions">
										<a href="#" class="fa fa-caret-down"></a>
										<a href="#" class="fa fa-times"></a>
									</div>
									<h2 class="panel-title">Total Saldo</h2>
								</header>
								<div class="panel-body">
								<h2>Rp.{{ number_format($totalSaldo) }}</h2>
								</div>
							</section>
						</div>

						<div class="col-md-5">
							<section class="panel">
								<header class="panel-heading">
									<div class="panel-actions">
										<a href="#" class="fa fa-caret-down"></a>
										<a href="#" class="fa fa-times"></a>
									</div>

									<h2 class="panel-title">Bunga Bulan Depan*</h2>
								</header>
								<div class="panel-body">
									<h2>Rp.{{ number_format($bungaDepan) }}</h2>
								</div>
							</section>
						</div>

						
					</div>

					<div class="row">
						<div class="col-md-1"></div>
						<div class="col-md-10">
							<section class="panel">
								<header class="panel-heading">
									<div class="panel-actions">
										<a href="#" class="fa fa-caret-down"></a>
										<a href="#" class="fa fa-times"></a>
									</div>
									<h2 class="panel-title">Transaksi Simpanan</h2>
									</header>
									<div class="panel-body">
										<table class="table table-bordered table-striped mb-none" id="datatable-default">
											<thead>
												<tr>
												<th>No</th>
												<th>No Anggota</th>
												<th>Tanggal</th>
												<th>Tarik</th>
												<th>Simpan</th>
												<th>Bunga</th>
												<th>Saldo</th>
												<th>Pegawai</th>
											</tr>
										</thead>
										<tbody>
											@php
												$saldo = 0;
											@endphp
											@foreach($transaksis as $transaksi)
											<tr>
												<td>{{ $loop->iteration }}</td>
												<td>{{ $transaksi->no_anggota }}</td>
												<td>{{ $transaksi->tanggal }}</td>
												@if($transaksi->jenis_transaksi == 1)
												<td></td>
												<td>Rp.{{ number_format($transaksi->nominal_transaksi) }}</td>
												<td></td>
												<td>Rp.{{ number_format($saldo = ($saldo + $transaksi->nominal_transaksi)) }}</td>
												@elseif($transaksi->jenis_transaksi == 2)
												<td>Rp.{{ number_format($transaksi->nominal_transaksi) }}</td>
												<td></td>
												<td></td>
												<td>Rp.{{ number_format($saldo = ($saldo - $transaksi->nominal_transaksi)) }}</td>
												@elseif($transaksi->jenis_transaksi == 3)
												<td></td>
												<td></td>
												<td>Rp.{{ number_format($transaksi->nominal_transaksi) }}</td>
												<td>Rp.{{ number_format($saldo = ($saldo + $transaksi->nominal_transaksi)) }}</td>
												@endif
												<td>{{$transaksi->nama_pegawai}}</td>
											</tr>
											@endforeach
										</tbody>
										</table>
									</div>

					</div>
						
					<!-- end: page -->
				</section>
			</div>

@endsection


@section('javascript')

<!-- Specific Page Vendor -->
<script src="{{asset('assets/vendor/select2/select2.js')}}"></script>
<script src="{{asset('assets/vendor/jquery-datatables/media/js/jquery.dataTables.js')}}"></script>
<script src="{{asset('assets/vendor/jquery-datatables/extras/TableTools/js/dataTables.tableTools.min.js')}}"></script>
<script src="{{asset('assets/vendor/jquery-datatables-bs3/assets/js/datatables.js')}}"></script>

@endsection

@push('javascript')
<script>
$("#datatable-default").dataTable();
</script>
@endpush
