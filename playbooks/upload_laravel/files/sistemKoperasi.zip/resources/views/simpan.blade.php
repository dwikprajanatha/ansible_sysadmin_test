@extends('template.app')

@section('header-nav','Form Simpanan')

@section('content')

					<!-- start: page -->
						<div class="row">
							<div class="col-xs-12">
							@if ($errors->any())
							<div class="alert alert-danger">
								<ul>
									@foreach ($errors->all() as $error)
										<li>{{ $error }}</li>
									@endforeach
								</ul>
							</div>
							@endif
								<section class="panel">
									<header class="panel-heading">
										<div class="panel-actions">
										</div>
						
										<h2 class="panel-title">Form Transaksi</h2>
									</header>
									<div class="panel-body">
										<form class="form-horizontal form-bordered" method="POST" action="{{url('simpan-cari')}}">
											@csrf
											<div class="form-group">
													<label class="col-md-3 control-label">No. Anggota</label>
													<div class="col-md-6">
														<div class="input-group input-search">
															<input type="text" class="form-control" name="no_anggota" id="q" placeholder="Cari No Anggota.." autocomplete="off">
															<span class="input-group-btn">
																<button class="btn btn-default" type="submit"><i class="fa fa-search"></i></button>
															</span>
														</div>
													</div>
												</div>
											</div>
						                                           									
										</form>
									</div>
								</section>
								
							</div>
							
						</div>
						
						
						
					<!-- end: page -->
				</section>
			</div>



	

@endsection