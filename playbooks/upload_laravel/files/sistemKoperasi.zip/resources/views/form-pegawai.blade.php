@extends('template.app')

@section('content')

                        <div class="row">
							<div class="col-lg-12">
								<section class="panel">
									<header class="panel-heading">
										<div class="panel-actions">
											<a href="#" class="fa fa-caret-down"></a>
											<a href="#" class="fa fa-times"></a>
										</div>
						
										<h2 class="panel-title">Form Pegawai</h2>
									</header>
									<div class="panel-body">
										<form class="form-horizontal form-bordered" method="POST" action="{{route('pegawai.store')}}">
                                        @csrf
											<div class="form-group">
												<label class="col-md-3 control-label" for="inputDefault">Nama</label>
												<div class="col-md-7">
													<input type="text" class="form-control" id="inputDefault" name="nama">
												</div>
											</div>

											<div class="form-group">
												<label class="col-md-3 control-label" for="inputDefault">Username</label>
												<div class="col-md-7">
													<input type="text" class="form-control" id="inputDefault" name="username">
												</div>
											</div>                                            

											<div class="form-group">
												<label class="col-md-3 control-label" for="inputDefault">Password</label>
												<div class="col-md-7">
													<input type="password" class="form-control" id="inputDefault" name="password">
												</div>
											</div>

											<div class="form-group">
												<label class="col-md-3 control-label" for="inputSuccess">Jabatan</label>
												<div class="col-md-7">
                                                    <select class="form-control mb-md" name="user_role">
                                                            <option value="1">Admin</option>
                                                            <option value="2">Pegawai Simpanan</option>
                                                            <option value="3">Pegawai Pinjaman</option>
                                                    </select>
                                                </div>
                                            </div>


                                            <div class="col-md-5"></div>
                                            <div class="col-md-5"><button type="submit" class="mb-xs mt-xs mr-xs btn btn-primary">Submit</button></div>
                                            



                                        </form>
                                    </div>
                                </section>
                            </div>
                        </div>


@endsection