@extends('template.app')

@section('css')
   
		<!-- Specific Page Vendor CSS -->
		<link rel="stylesheet" href="{{asset('assets/vendor/select2/select2.css')}}" />
		<link rel="stylesheet" href="{{asset('assets/vendor/jquery-datatables-bs3/assets/css/datatables.css')}}" />


@endsection

@section('header-nav','List Nasabah')

@section('content')
<div class="row">
<div class="col-md-14">
   <section class="panel">
      <header class="panel-heading">
         <div class="panel-actions">
            <a href="#" class="fa fa-caret-down"></a>
            <a href="#" class="fa fa-times"></a>
         </div>
         <h2 class="panel-title">List Nasabah</h2>
							</header>
							<div class="panel-body">
								<table class="table table-bordered table-striped mb-none" id="datatable-default">
									<thead>
										<tr>
											<th style="text-align:center">No</th>
											<th style="text-align:center">No. Anggota</th>
											<th style="text-align:center">Nama</th>
											<th style="text-align:center">Alamat</th>
                                            <th style="text-align:center">Telepon</th>
                                            <th style="text-align:center">No Identitas</th>
                                            <th style="text-align:center">Jenis Kelamin</th>
                                            <th style="text-align:center">Pembuat</th>
                                            <th style="text-align:center">Status Aktif</th>
                                            <th style="text-align:center">Action</th>
										</tr>
									</thead>
                                    <tbody>
                                        @php 
                                                $i = 1;
                                        @endphp
                                        @foreach($Nasabahs as $Nasabah)
                                        <tr>
                                            <td>{{$i++}}</td>
                                            <td><a href="{{route('nasabah.show',[$Nasabah->id]) }}">{{$Nasabah -> no_anggota}}</a></td>
                                            <td>{{$Nasabah -> nama}}</td>
                                            <td>{{$Nasabah -> alamat}}</td>
                                            <td>{{$Nasabah -> telepon}}</td>
                                            <td>{{$Nasabah -> noktp}}</td>
                                            <td>{{$Nasabah -> kelamin}}</td>
                                            <td>{{$Nasabah -> nama_pegawai}}</td>
                                            
                                            @if( $Nasabah->status_aktif != 1)
                                            <td>Tidak Aktif</td>
                                            @else
                                            <td>Aktif</td>
                                            @endif
                                            <td>
                                                <table>
                                                    <tr>
                                                        <td>
                                                            <form action="{{ route('nasabah.destroy', [$Nasabah->id]) }}" method="POST">
                                                                 @csrf
                                                                {{ method_field('DELETE') }}
                                                                <button type="submit" class="mb-xs mt-xs mr-xs btn btn-danger"><i class="fa fa-times"></i></button>
                                                            </form>
                                                        </td>
                                                        <td><a href="{{ route('nasabah.edit', [$Nasabah->id]) }}"><button type="button" class="mb-xs mt-xs mr-xs btn btn-warning"><i class="fa fa-pencil"></i></button></a></td>
                                                    </tr>
                                                </table>
                                                

                                            </td>
                                            
                                        </tr>

                                        @endforeach
                                    </tbody>
                                    </table>
                                </div>
                            </div>
                        </section>
                        </div>
                        </div>
@endsection

@section('javascript')

        <!-- Specific Page Vendor -->
        <script src="{{asset('assets/vendor/select2/select2.js')}}"></script>
		<script src="{{asset('assets/vendor/jquery-datatables/media/js/jquery.dataTables.js')}}"></script>
		<script src="{{asset('assets/vendor/jquery-datatables/extras/TableTools/js/dataTables.tableTools.min.js')}}"></script>
		<script src="{{asset('assets/vendor/jquery-datatables-bs3/assets/js/datatables.js')}}"></script>

@endsection



@push('javascript')
    <script>
        $("#datatable-default").dataTable();
    </script>
@endpush
