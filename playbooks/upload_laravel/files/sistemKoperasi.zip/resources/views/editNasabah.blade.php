@extends('template.app')
@section('header-nav','Edit Nasabah')

@section('content')




					<!-- start: page -->
						<div class="row">
							<div class="col-lg-1"></div>
							<div class="col-lg-10">
								<section class="panel">
									<header class="panel-heading">
										<div class="panel-actions">
											<a href="#" class="fa fa-caret-down"></a>
											<!-- <a href="#" class="fa fa-times"></a> -->
										</div>
						
										<h2 class="panel-title">Formulir Daftar Nasabah</h2>
									</header>
									<div class="panel-body">
										<form class="form-horizontal form-bordered" method="POST" action="{{route('nasabah.update',[$data],[$data->id])}}">
                                            @csrf
                                            {{ method_field('PUT') }}
											<div class="form-group">
												<label class="col-md-2 control-label" for="inputDefault">Nama</label>
												<div class="col-md-9">
													<input type="text" class="form-control" id="" name="nama" value="{{$data->nama}}">
												</div>
											</div>

											<div class="form-group">
												<label class="col-md-2 control-label" for="inputDefault">Alamat</label>
												<div class="col-md-9">
													<input type="text" class="form-control" id="" name="alamat" value="{{$data->alamat}}">
												</div>
											</div>

											<div class="form-group">
												<label class="col-md-2 control-label" for="inputDefault">Telepon</label>
												<div class="col-md-9">
													<input type="text" class="form-control" id="" name="telepon" value="{{$data->telepon}}">
												</div>
											</div>
											
											<div class="form-group">
												<label class="col-md-2 control-label" for="inputDefault">No. KTP</label>
												<div class="col-md-9">
													<input type="text" class="form-control" id="" name="noktp" value="{{$data->noktp}}">
												</div>
											</div>
											
											<div class="form-group">
												<label class="col-md-3 control-label" for="inputDefault">Jenis Kelamin</label>
												<div class="col-md-8">
													<select class="form-control mb-md" id="" name="jeniskelamin">
                                                        <option value="" hidden selected>Pilih Salah Satu</option>
                                                        
                                                        @if($data->kelamin == 'Pria')
														<option value="1" selected>Laki - Laki</option>
                                                        <option value="2">Perempuan</option>
                                                        @else
                                                        <option value="1">Laki - Laki</option>
                                                        <option value="2" selected>Perempuan</option>
                                                        @endif
													</select>
												</div>
											</div>
											<center><input type="submit" class="mb-xs mt-xs mr-xs btn btn-primary" value="Submit"></center>
										</form>
									</div>
								</section>
							</div>
						</div>
					<!-- end: page -->
				
			

@endsection