@extends('template.app')

@section('header-nav','Bunga')

@section('content')

                    <div class="row">
                            <div class="col-lg-1"></div>
                                <div class="col-lg-10">
                                    <section class="panel">
                                        <header class="panel-heading">
                                            <div class="panel-actions">
                                                <a href="#" class="fa fa-caret-down"></a>
                                                <a href="#" class="fa fa-times"></a>
                                            </div>
                            
                                            <h2 class="panel-title">Form Bunga</h2>
                                        </header>
                                        <div class="panel-body">
                                            <form class="form-horizontal form-bordered" method="POST" action="{{route('simpanan.store')}}">
											@csrf


                                            <div class="form-group">

                                                <label class="col-md-3 control-label">Bunga</label>
                                                <div class="col-md-7">
                                                    <div class="input-group mb-md">
                                                            <input type="text" class="form-control" name="bunga">
                                                            <span class="input-group-addon btn-success">%</span>
                                                    </div>
                                                </div>  
                                            </div> 

                                            <div class="form-group">
												<label class="col-md-3 control-label">Tanggal Berlaku</label>
												<div class="col-md-6">
													<div class="input-group">
														<span class="input-group-addon">
															<i class="fa fa-calendar"></i>
														</span>
														<input type="text" class="form-control datepicker" name="tanggal_mulai_berlaku">
													</div>
												</div>
											</div>

                                            <div class="form-group">
                                                <div class="col-md-5"></div>
                                                    <button type="submit" class="mb-xs mt-xs mr-xs btn btn-primary">Submit</button>
                                            </div>


                                            </form>    
                                        </div>



@endsection

@push('javascript')

<script>



$('.datepicker').datepicker({
    format: 'yyyy-mm-dd',
    autoclose: 1,
    pickerPosition: "top-right"
});


</script>

@endpush