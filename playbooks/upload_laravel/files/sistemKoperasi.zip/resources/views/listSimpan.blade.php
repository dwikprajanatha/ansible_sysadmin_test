@extends('template.app')

@section('css')
   
   <!-- Specific Page Vendor CSS -->
   <link rel="stylesheet" href="{{asset('assets/vendor/select2/select2.css')}}" />
   <link rel="stylesheet" href="{{asset('assets/vendor/jquery-datatables-bs3/assets/css/datatables.css')}}" />


@endsection

@section('header-nav','List Transaksi Simpan')

@section('content')

                           
<div class="row">
<div class="col-md-12">
   <section class="panel">
      <header class="panel-heading">
         <div class="panel-actions">
            <a href="#" class="fa fa-caret-down"></a>
            <a href="#" class="fa fa-times"></a>
         </div>
         <h2 class="panel-title">List Transaksi</h2>
							</header>
		<div class="panel-body">
			<table class="table table-bordered table-striped mb-none" id="datatable-default">
				<thead>
				    <tr>
                     <th>No</th>
                     <th>No Anggota</th>
                     <th>Nama Nasabah</th>
					 <th>Tanggal</th>
					 <th>Jenis Transaksi</th>
					 <th>Nominal</th>
                     <th>Pegawai</th>
                  </tr>
               </thead>
               <tbody>
                  @foreach($Simpans as $Simpan)
                  <tr>
                     <td>{{$loop->iteration}}</td>
                     <td><a href="{{route('nasabah.show',[$Simpan->anggota_id]) }}">{{$Simpan -> no_anggota}}</a></td>
                     <td>{{$Simpan -> nama}}</td>
                     <td>{{$Simpan -> tanggal}}</td>
                     <td>{{$Simpan -> transaksi}}</td>
                     <td>Rp.{{number_format($Simpan -> nominal_transaksi)}}</td>
                     <td>{{$Simpan -> nama_pegawai}}</td>
                  </tr>
                  @endforeach
               </tbody>
            </table>
         </div>
      </div>
   </section>
</div>
</div>


@endsection

@section('javascript')

<!-- Specific Page Vendor -->
<script src="{{asset('assets/vendor/select2/select2.js')}}"></script>
<script src="{{asset('assets/vendor/jquery-datatables/media/js/jquery.dataTables.js')}}"></script>
<script src="{{asset('assets/vendor/jquery-datatables/extras/TableTools/js/dataTables.tableTools.min.js')}}"></script>
<script src="{{asset('assets/vendor/jquery-datatables-bs3/assets/js/datatables.js')}}"></script>

@endsection



