@extends('template.app')

@section('header-nav','List Pegawai')

@section('content')

<div class="row">
<div class="col-md-12">
   <section class="panel">
      <header class="panel-heading">
         <div class="panel-actions">
            <a href="#" class="fa fa-caret-down"></a>
            <a href="#" class="fa fa-times"></a>
         </div>
         <h2 class="panel-title">Pegawai</h2>
      </header>
      <div class="panel-body">
         <div class="table-responsive">
            <table class="table table-striped mb-none">
               <thead>
                  <tr>
                     <th>No</th>
                     <th>NIK</th>
                     <th>Nama</th>
                     <th>Jabatan</th>
                  </tr>
               </thead>
               <tbody>
                  @foreach($Users as $User)
                  <tr>
                     <td>{{$loop->iteration}}</td>
                     <td>{{$User->nik}}</td>
                     <td>{{$User->nama_pegawai}}</td>
                     @if($User->user_role == 1)
                     <td>Admin</td>
                     @elseif($User->user_role == 2)
                     <td>Pegawai Simpanan</td>
                     @else
                     <td>Pegawai Pinjaman</td>
                     @endif
                  </tr>
                  @endforeach
               </tbody>
            </table>
         </div>
         <a href="{{url('pegawai/create')}}"><button type="button" class="mb-xs mt-xs mr-xs btn btn-primary">Tambah</button></a>
      </div>
   </section>
</div>
</div>



@endsection