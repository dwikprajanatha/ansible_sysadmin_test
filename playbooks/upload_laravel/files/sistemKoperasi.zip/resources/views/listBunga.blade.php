

@extends('template.app')

@section('header-nav','List Bunga')

@section('content')
<div class="row">
    <div class="col-md-12">
    @if ($errors->any())
		<div class="alert alert-danger">
		    <ul>
			@foreach ($errors->all() as $error)
			    <li>{{ $error }}</li>
			@endforeach
			</ul>
		</div>
	@endif
        <section class="panel">
            <header class="panel-heading">
                <div class="panel-actions">
                    <a href="#" class="fa fa-caret-down"></a>
                    <a href="#" class="fa fa-times"></a>
                </div>
                <h2 class="panel-title">List Transaksi</h2>
            </header>
            <div class="panel-body">
                <table class="table table-bordered table-striped mb-none" id="datatable-default">
                <a href="{{route('simpanan.create')}}"><button type="button" class="mb-xs mt-xs mr-xs btn btn-success">Tambah Bunga</button></a>
                <a href="{{url('bunga/hitung_bunga')}}"><button type="button" class="mb-xs mt-xs mr-xs btn btn-warning">Hitung Bunga</button></a>
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Bulan</th>
                            <th>Tahun</th>
                            <th>Tanggal</th>
                            <th>Persentase Bunga</th>
                            <th>Pegawai</th>
                        </tr>
                    </thead>
                    @foreach($datas as $data)
                    <tr>
                        <td>{{$loop->iteration}}</td>
                        <td>{{$data->trx_bulan}}</td>
                        <td>{{$data->trx_tahun}}</td>
                        <td>{{$data->tanggal_proses}}</td>
                        <td>{{$data->persentase_bunga}}%</td>
                        <td>{{$data->nama_pegawai}}</td>
                    </tr>
                    @endforeach
                    </tbody>
                </table>
            </div>
        </section>
    </div>
</div>



@endsection
