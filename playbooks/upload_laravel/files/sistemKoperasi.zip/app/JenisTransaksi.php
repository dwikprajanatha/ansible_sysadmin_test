<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class JenisTransaksi extends Model
{
    protected $fillable = [
        
        'transaksi',
        'tipe',

    ];

}
