<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\MasterBungaSimpanan;
use App\PerhitunganBungaSimpanan;
use App\Anggota;
use App\Simpanan;
use DB;
use Auth;

class BungaController extends Controller
{
    public function __construct() {
        $this->middleware('auth');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $datas = DB::table('perhitungan_bunga_simpanans')
                ->join('users','perhitungan_bunga_simpanans.id_user','=','users.id')
                ->get();
            
   
        return view('listBunga',[
            'datas' => $datas
        ]);

        
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('bunga');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $data = [
            'persentase' => $request->bunga,
            'tanggal_mulai_berlaku' => $request->tanggal_mulai_berlaku,
        ];
        $data = MasterBungaSimpanan::create($data);

        return redirect('bunga/simpanan');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function hitungBunga()
    {
        $last_trx = PerhitunganBungaSimpanan::select('trx_bulan','trx_tahun')->orderBy('id','DESC')->first();

        if ($last_trx->trx_bulan != DATE('m') || $last_trx->trx_tahun != DATE('Y')) {
        
            $bunga = MasterBungaSimpanan::select('id','persentase')->where('tanggal_mulai_berlaku','<=',date('Y-m-d'))->first();
            
            

            $nasabahs = Anggota::select('id')->where('status_aktif','=',1)->get();

            DB::beginTransaction();
            try{

            foreach($nasabahs as $nasabah){

                $saldo = Simpanan::where('anggota_id','=',$nasabah->id)->where('jenis_transaksi','=',1)->sum('nominal_transaksi');
                
                if($saldo != 0){
                
                        $total_bunga = $saldo * ($bunga->persentase / 100);
                    
                            $data = [
                                'anggota_id' => $nasabah->id,
                                'tanggal' => date('Y-m-d H:i:s'),
                                'jenis_transaksi' => 3,
                                'nominal_transaksi' => $total_bunga,
                                'id_user' => Auth::user()->id,
                            ];
            
                            $data = Simpanan::create($data);
                
                    }

            }


            $inserttrx = [
                'trx_bulan' => date('m'),
                'trx_tahun' => date('Y'),
                'tanggal_proses' => date('Y-m-d H:i:s'),
                'persentase_bunga' => $bunga->persentase,
                'id_user' => Auth::user()->id,
            ];

            $inserttrx = PerhitunganBungaSimpanan::create($inserttrx);

        } catch(\Exception $error){
            DB::rollback();
        
        }  DB::commit();

            return redirect()->route('simpanan.index');
        
        } else {

            return redirect()->route('simpanan.index')->withErrors('Bunga sudah di Hitung!');

        }
        

    }

}
