<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Anggota;
use App\Simpanan;
use App\MasterBungaSimpanan;
use Auth;
use DB;

class ControllerSimpan extends Controller
{

    public function __construct() {
        $this->middleware('auth');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $dataSimpan = DB::table('simpanans')
                    ->join('anggotas','simpanans.anggota_id','=','anggotas.id')
                    ->join('jenis_transaksis','simpanans.jenis_transaksi','=','jenis_transaksis.id')
                    ->join('users','simpanans.id_user','=','users.id')
                    ->get();

        
        return view('listSimpan',[
            'Simpans' => $dataSimpan
        ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create($request)
    {

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        if($request->id_nasabah != 0){
            
            $simpan = new Simpanan;

            $simpan->anggota_id = $request->id_nasabah;
            $simpan->tanggal = date('Y-m-d H:i:s');
            $simpan->jenis_transaksi = $request->jenisTransaksi;
            $simpan->nominal_transaksi = $request->nominal;
            $simpan->id_user = Auth::user()->id;

            $simpan->save();

            return redirect('simpan');

        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function check()
    {
        return view('simpan');
    }

    public function checkData(Request $request)
    {
        $no_anggota = $request->no_anggota;

        $dataAnggotas = Anggota::where('no_anggota',$no_anggota)->first();

        if(!$dataAnggotas){
            return redirect()->back()->withErrors('Data Not Found!');
        }

        $transaksis = DB::table('simpanans')
        ->join('Anggotas','simpanans.anggota_id','=','Anggotas.id')
        ->join('Users','simpanans.id_user','=','Users.id')
        ->where('anggota_id',$dataAnggotas->id)->get();

        $saldoSimpan = Simpanan::where('anggota_id','=',$dataAnggotas->id)->where('jenis_transaksi','=',1)->sum('nominal_transaksi');
        $saldoTarik = Simpanan::where('anggota_id','=',$dataAnggotas->id)->where('jenis_transaksi','=',2)->sum('nominal_transaksi');
        $totalBunga = Simpanan::where('anggota_id','=',$dataAnggotas->id)->where('jenis_transaksi','=',3)->sum('nominal_transaksi');
        $bunga = MasterBungaSimpanan::select('persentase')->where('tanggal_mulai_berlaku','<=',date('Y-m-d'))->first();
        $total_saldo = $saldoSimpan - $saldoTarik;
        $total_saldo = $total_saldo + $totalBunga;

        $bungaDepan = $total_saldo * ($bunga->persentase / 100);

        
        return view('form-simpan',[
            'dataAnggotas' => $dataAnggotas,
            'transaksis' => $transaksis,
            'totalSaldo' => $total_saldo,
            'bungaDepan' => $bungaDepan,
        ]);
    }
}
