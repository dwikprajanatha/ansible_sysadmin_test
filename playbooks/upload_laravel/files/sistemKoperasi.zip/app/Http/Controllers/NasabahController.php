<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Anggota;
use App\Simpanan;
use App\MasterBungaSimpanan;
use DB;
use Auth;

class NasabahController extends Controller
{
    public function __construct() {
        $this->middleware('auth');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $anggotas = DB::table('anggotas')->select('anggotas.*','users.nama_pegawai')
                        ->join('users','anggotas.user_id','=','users.id')
                        ->get();

        return view('listNasabah',[
            'Nasabahs' => $anggotas
        ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('daftar');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $date = date('Ymd');
        
        $angkaBelakang = DB::table('anggotas')->where('no_anggota','like',$date.'%')->max('no_anggota');
        


        if($angkaBelakang == NULL || $angkaBelakang == 0){

            $belakang = '0001';
            $no_anggota = $date.$belakang;

        } else {

            $maxBelakang = DB::table('anggotas')->where('no_anggota','like',$date.'%')->max('no_anggota');

            $no_anggota = $maxBelakang + 1;

        }



        $data = new Anggota;
        $data->no_anggota = $no_anggota;
        $data->nama = $request->nama;
        $data->alamat = $request->alamat;
        $data->telepon = $request->telepon;
        $data->noktp = $request->noktp;
        $data->kelamin = $request->jeniskelamin;
        $data->status_aktif = 1;
        $data->user_id = Auth::user()->id;

        $data->save();

        return redirect('nasabah');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {

        $dataAnggotas = Anggota::where('id',$id)->first();

        $transaksis = DB::table('simpanans')
        ->join('Anggotas','simpanans.anggota_id','=','anggotas.id')
        ->join('Users','simpanans.id_user','=','users.id')
        ->where('anggota_id',$dataAnggotas->id)->orderBy('tanggal','ASC')->get();


        $saldoSimpan = Simpanan::where('anggota_id','=',$dataAnggotas->id)->where('jenis_transaksi','=',1)->sum('nominal_transaksi');
        $saldoTarik = Simpanan::where('anggota_id','=',$dataAnggotas->id)->where('jenis_transaksi','=',2)->sum('nominal_transaksi');
        $totalBunga = Simpanan::where('anggota_id','=',$dataAnggotas->id)->where('jenis_transaksi','=',3)->sum('nominal_transaksi');
        $bunga = MasterBungaSimpanan::select('persentase')->where('tanggal_mulai_berlaku','<=',date('Y-m-d'))->first();
        $total_saldo = $saldoSimpan - $saldoTarik;
        $total_saldo = $total_saldo + $totalBunga;

        $bungaDepan = $total_saldo * ($bunga->persentase / 100);


        return view('detail_nasabah',[
            'nasabah' => $dataAnggotas,
            'transaksis' => $transaksis,
            'totalSaldo' => $total_saldo,
            'bungaDepan' =>$bungaDepan
        ]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {

        $data = Anggota::where('id','=',$id)->first();

        return view('editNasabah',[
            'data' => $data
        ]);

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
       $data = Anggota::find($id);

        $data->nama = $request->nama;
        $data->alamat = $request->alamat;
        $data->telepon = $request->telepon;
        $data->noktp = $request->noktp;
        $data->kelamin = $request->jeniskelamin;
        $data->status_aktif = 1;
        $data->user_id = Auth::user()->id;

        $data->save();

        return redirect('nasabah');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
       $data = Anggota::find($id);
        
       $data->status_aktif = 0;
       $data->save();

       return redirect('nasabah');
    }
}
