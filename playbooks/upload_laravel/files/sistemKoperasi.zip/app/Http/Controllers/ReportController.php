<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;

class ReportController extends Controller
{

    public function __construct() {
        $this->middleware('auth');
    }

    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function __invoke(Request $request)
    {
        //
    }

    public function weekly()
    {


        //<start> buat graph <start>
        $today = date_create();
        
        if($today->format('D') != 'Mon'){

            $last_monday = date('Y-m-d', strtotime('Last Monday'));

        } else {

            $last_monday = $today->format('Y-m-d');
            
        }


        $end_saturday = date('Y-m-d', strtotime('Next Saturday'));

        $diff = date_diff((date_create($end_saturday)),(date_create($last_monday)));

        $batas = $diff->format("%a");

        $reports = [];

        $haha = [];

        $i = 0;

    if($today->format('D') != 'Sat' && $today->format('D') != 'Sun'){
        
        while($i <= $batas){
                $date = date_create($last_monday);
                    
                $day_unix = date_add($date,date_interval_create_from_date_string($i."days"));

                $day = $day_unix->format('Y-m-d');
    
                $report = DB::table('simpanans')->select(DB::raw('COUNT(simpanans.id) as id'))->where(DB::raw("(STR_TO_DATE(tanggal,'%Y-%m-%d'))"),$day)->first();
                    
                array_push($reports,$report);
                    
                $day = $day_unix->format('d F Y');
                    
                array_push($haha,$day);
    
                $i++;

        }
        
    } elseif($today->format('D') == 'Sat'){

        $batas = 5;

        while($i <= $batas){

            $jani = date_create();
                
            $day_unix = date_sub($jani,date_interval_create_from_date_string($i."days"));

            $day = $day_unix->format('Y-m-d');

            $report = DB::table('simpanans')->select(DB::raw('COUNT(simpanans.id) as id'))->where('simpanans.jenis_transaksi',1)->where(DB::raw("(STR_TO_DATE(tanggal,'%Y-%m-%d'))"),$day)->first();
                
            array_push($reports,$report);
                
            $day = $day_unix->format('d F Y');
                
            array_push($haha,$day);

            $i++;

        } 

        $reports = array_reverse($reports);
                    
        $haha = array_reverse($haha);
    
    } elseif($today->format('D') == 'Sun'){

                $batas = 5;
                $i = 1;
                
                while($i <= $batas){
        
                    $jani = date_create();
                        
                    $day_unix = date_sub($jani,date_interval_create_from_date_string($i."days"));
        
                    $day = $day_unix->format('Y-m-d');
        
                    $report = DB::table('simpanans')->select(DB::raw('COUNT(simpanans.id) as id'))->where('simpanans.jenis_transaksi',1)->where(DB::raw("(STR_TO_DATE(tanggal,'%Y-%m-%d'))"),$day)->first();
                        
                    array_push($reports,$report);
                        
                    $day = $day_unix->format('d F Y');
                        
                    array_push($haha,$day);


        
                    $i++;
                }

                $reports = array_reverse($reports);
                    
                $haha = array_reverse($haha);

        }

        $total_nabung = DB::table('simpanans')
                        ->join('jenis_transaksis','simpanans.jenis_transaksi','=','jenis_transaksis.id')
                        ->select(DB::raw("SUM(simpanans.nominal_transaksi * jenis_transaksis.tipe) AS 'total'"))
                        ->where('simpanans.jenis_transaksi',1)
                        ->whereBetween(DB::raw("DATE(simpanans.tanggal)"),[$last_monday,$end_saturday])
                        ->first();

        $total_narik = DB::table('simpanans')
                        ->join('jenis_transaksis','simpanans.jenis_transaksi','=','jenis_transaksis.id')
                        ->select(DB::raw("SUM(simpanans.nominal_transaksi * jenis_transaksis.tipe) AS 'total'"))
                        ->where('simpanans.jenis_transaksi',2)
                        ->whereBetween(DB::raw("DATE(simpanans.tanggal)"),[$last_monday,$end_saturday])
                        ->first();


        // $total_nabung = DB::select(DB::raw("SELECT SUM(simpanans.`nominal_transaksi`*jenis_transaksis.`tipe`) AS 'total' FROM simpanans 
        // INNER JOIN jenis_transaksis ON simpanans.`jenis_transaksi` = jenis_transaksis.`id` 
        // WHERE simpanans.jenis_transaksi = 1  AND DATE(simpanans.`tanggal`) BETWEEN :awal AND :akhir"),array(
        //     'awal' => $last_monday,
        //     'akhir' => $end_saturday)
        // );

        
        

        $last_sat = date('Y-m-d', strtotime('Last Saturday'));

        $last_sat_unix = date_create($last_sat);

        $one_week_last_mon = date_sub($last_sat_unix,date_interval_create_from_date_string("5 days"));

        $one_week_last_mon = $one_week_last_mon->format('Y-m-d');

        $one_week_earlier = DB::table('simpanans')->select(DB::raw("COUNT(simpanans.id) as 'total'"))->where('simpanans.jenis_transaksi',1)->whereBetween(DB::raw("DATE(simpanans.tanggal)"),[$one_week_last_mon,$last_sat])->first();

        $total_now = array_sum($reports);

        $selisih = $total_now - $one_week_earlier->total;

        //<end> buat graph <end>

        //<start> buat tabel tabungan <start>

        $ids = [1,2];

        if($today->format('D') != 'Sun' && $today->format('D') != 'Sat'){

            $tabungan = DB::table('simpanans')
            ->join('anggotas','simpanans.anggota_id','=','anggotas.id')
            ->join('jenis_transaksis','simpanans.jenis_transaksi','=','jenis_transaksis.id')
            ->join('users','simpanans.id_user','=','users.id')
            ->whereIn('simpanans.jenis_transaksi',$ids)->whereBetween(DB::raw("DATE(simpanans.tanggal)"),[$last_monday,$end_saturday])
            ->get();

        } elseif($today->format('D') == 'Sat'){

            $end_saturday = $today->format('Y-m-d');

            $tabungan = DB::table('simpanans')
            ->join('anggotas','simpanans.anggota_id','=','anggotas.id')
            ->join('jenis_transaksis','simpanans.jenis_transaksi','=','jenis_transaksis.id')
            ->join('users','simpanans.id_user','=','users.id')
            ->whereIn('simpanans.jenis_transaksi',$ids)->whereBetween(DB::raw("DATE(simpanans.tanggal)"),[$last_monday,$end_saturday])
            ->get();


        } elseif($today->format('D') == 'Sun'){

            $end_saturday = date_sub($today,date_interval_create_from_date_string("1 Day"));

            $end_saturday = $end_saturday->format('Y-m-d');

            $tabungan = DB::table('simpanans')
            ->join('anggotas','simpanans.anggota_id','=','anggotas.id')
            ->join('jenis_transaksis','simpanans.jenis_transaksi','=','jenis_transaksis.id')
            ->join('users','simpanans.id_user','=','users.id')
            ->whereIn('simpanans.jenis_transaksi',$ids)->whereBetween(DB::raw("DATE(simpanans.tanggal)"),[$last_monday,$end_saturday])
            ->get();

        }


        // <end> buat tabel tabungan <end>

        $total_nasabah_sekarang = DB::table('anggotas')
                                    ->select(DB::raw("COUNT(anggotas.id) AS 'total'"))
                                    ->where(DB::raw("WEEK('created_at')"),$today->format('W'))
                                    ->first();


        $seminggu_lalu = date_create();
        
        date_sub($seminggu_lalu,date_interval_create_from_date_string("1 Week"));

        $total_nasabah_kemarin = DB::table('anggotas')
                                ->select(DB::raw("COUNT(anggotas.id) AS 'total'"))
                                ->where(DB::raw("WEEK('created_at')"),$seminggu_lalu->format('W'))
                                ->first();


        $total_nasabah_sekarang = $total_nasabah_sekarang->total;
        $total_nasabah_kemarin = $total_nasabah_kemarin->total;


        $selisih_nasabah = $total_nasabah_sekarang - $total_nasabah_kemarin;

        $total_uang = DB::table('simpanans')
                        ->join('jenis_transaksis','simpanans.jenis_transaksi','=','jenis_transaksis.id')
                        ->select(DB::raw("SUM(simpanans.nominal_transaksi * jenis_transaksis.tipe) as 'total'"))
                        ->whereIn('simpanans.jenis_transaksi',[1,2])
                        ->first();
       
        $total_uang = $total_uang->total;

        return view("weekly_report",[
            'days' => $haha,
            'reports' => $reports,
            'tabungan' => $total_nabung,
            'tarikan' => $total_narik,
            'selisih' => $selisih,
            'simpanan' => $tabungan,
            'nasabah_sekarang' => $total_nasabah_sekarang,
            'selisih_nasabah' => $selisih_nasabah,
            'total_uang' => $total_uang,
            
        ]);



    }



    public function weekly_search(Request $tgl)
    {

        $tgl = date_create($tgl->tgl);
        $tgl = $tgl->format('W');


        
    }


    public function monthly()
    {

        $first_day = date('Y-m-01');

        $first_day = date_create($first_day);

        $i = 1;

        if($first_day->format('D') != 'Sun' && $first_day->format('D') != 'Mon'){

            while (true) {

                $first_day_on_week = date_sub($first_day,date_interval_create_from_date_string($i."days"));

                if($first_day_on_week->format('D') == 'Mon'){

                    $last_day_on_week = clone $first_day_on_week;

                    date_add($last_day_on_week,date_interval_create_from_date_string("5 Days"));

                    break;

                } else {
                    continue;
                }
                
            }
        } else {

            while (true) {

                    $first_day_on_week = clone $first_day;

                    $last_day_on_week = clone $first_day_on_week;

                    date_add($last_day_on_week,date_interval_create_from_date_string("5 Days"));

                    break;

                }
            
            
        }

        $a = 0;

        $ids = [1,2];

        $report_weeks = [];

        $tgl_awal = [];
        $tgl_akhir = [];

        $awal = $first_day_on_week->format('Y-m-d');
        $akhir = $last_day_on_week->format('Y-m-d');
        
        
        array_push($tgl_awal,$awal);
        array_push($tgl_akhir,$akhir);


        $awal_unix = date_create($awal);
        $akhir_unix = date_create($akhir);

        //start: cari 1 minggu dalam satu bulan 
        
        while ($a < 3) {
            
            date_add($awal_unix,date_interval_create_from_date_string("7 Days"));
            date_add($akhir_unix,date_interval_create_from_date_string("7 Days"));

            $awal = $awal_unix->format('Y-m-d');
            $akhir = $akhir_unix->format('Y-m-d');

            array_push($tgl_awal,$awal);
            array_push($tgl_akhir,$akhir);

            $a++;

        }

        //end: cari 1 minggu dalam satu bulan 

        $a = 0;
        $total_simpan = [];
        while ($a < 4) {

            $total_nabung = DB::select(DB::raw("SELECT SUM(simpanans.`nominal_transaksi`) AS 'total', COUNT(simpanans.id) AS 'total_trx' FROM simpanans 
            INNER JOIN jenis_transaksis ON simpanans.`jenis_transaksi` = jenis_transaksis.`id` 
            WHERE jenis_transaksi = 1 AND DATE(simpanans.`tanggal`) BETWEEN :awal AND :akhir"),array(
                'awal' => $tgl_awal[$a],
                'akhir' => $tgl_akhir[$a])
            );

            array_push($total_simpan,$total_nabung[0]->total_trx);

            array_push($report_weeks,$total_nabung[0]->total);

            $a++;
        }

        $total_simpanan_sebulan = array_sum($total_simpan);


            // $report_week = DB::table('simpanans')
            //                 ->whereIn('simpanans.jenis_transaksi',$ids)
            //                 ->whereBetween(DB::raw("DATE('simpanans.tanggal')"),[$awal,$akhir])
            //                 ->sum();


        $today = date_create();
        
        $total_saldo_sebulan = DB::table('simpanans')
                                ->join('jenis_transaksis','simpanans.jenis_transaksi','=','jenis_transaksis.id')
                                ->select(DB::raw("SUM(simpanans.nominal_transaksi * jenis_transaksis.tipe) AS 'total'"))
                                ->whereIn('simpanans.jenis_transaksi',[1,2])
                                ->where(DB::raw("MONTH(simpanans.tanggal)"),$today->format('m'))
                                ->first();


        $avg_saldo_sebulan = DB::table('simpanans')
                                ->join('jenis_transaksis','simpanans.jenis_transaksi','=','jenis_transaksis.id')
                                ->select(DB::raw("AVG(simpanans.nominal_transaksi * jenis_transaksis.tipe) AS 'total'"))
                                ->whereIn('simpanans.jenis_transaksi',[1,2])
                                ->where(DB::raw("MONTH(simpanans.tanggal)"),$today->format('m'))
                                ->first();
        
        $one_month_ago = date_create();

        date_sub($one_month_ago,date_interval_create_from_date_string('1 Month'));

        $total_transaksi_bulan_lalu = DB::table('simpanans')
                                        ->join('jenis_transaksis','simpanans.jenis_transaksi','=','jenis_transaksis.id')
                                        ->select(DB::raw("COUNT(simpanans.id) AS 'total'"))
                                        ->whereIn('simpanans.jenis_transaksi',[1,2])
                                        ->where(DB::raw("MONTH(simpanans.tanggal)"),$one_month_ago->format('m'))
                                        ->first();

        $total_transaksi_bulan_lalu = $total_transaksi_bulan_lalu->total;

        $selisih = $total_simpanan_sebulan - $total_transaksi_bulan_lalu;




        $transaksi_sebulan = DB::table('simpanans')
                            ->join('anggotas','simpanans.anggota_id','=','anggotas.id')
                            ->join('jenis_transaksis','simpanans.jenis_transaksi','=','jenis_transaksis.id')
                            ->join('users','simpanans.id_user','=','users.id')
                            ->whereIn('simpanans.jenis_transaksi',[1,2])
                            ->where(DB::raw("MONTH(simpanans.tanggal)"),$today->format('m'))
                            ->get();


        $transaksi_bunga = DB::table('simpanans')
                            ->join('anggotas','simpanans.anggota_id','=','anggotas.id')
                            ->join('jenis_transaksis','simpanans.jenis_transaksi','=','jenis_transaksis.id')
                            ->join('users','simpanans.id_user','=','users.id')
                            ->where('simpanans.jenis_transaksi',3)
                            ->where(DB::raw("MONTH(simpanans.tanggal)"),$today->format('m'))
                            ->get();
        


        $total_nasabah_sekarang = DB::table('anggotas')
                            ->select(DB::raw("COUNT(anggotas.id) AS 'total'"))
                            ->where(DB::raw("WEEK('created_at')"),$today->format('W'))
                            ->first();


        $bulan_lalu = clone $today;

        date_sub($bulan_lalu,date_interval_create_from_date_string("1 Month"));

        $total_nasabah_kemarin = DB::table('anggotas')
                                ->select(DB::raw("COUNT(anggotas.id) AS 'total'"))
                                ->where(DB::raw("MONTH('created_at')"),$bulan_lalu->format('W'))
                                ->first();


        $total_nasabah_sekarang = $total_nasabah_sekarang->total;
        $total_nasabah_kemarin = $total_nasabah_kemarin->total;


        $selisih_nasabah = $total_nasabah_sekarang - $total_nasabah_kemarin;

        $total_uang = DB::table('simpanans')
                        ->join('jenis_transaksis','simpanans.jenis_transaksi','=','jenis_transaksis.id')
                        ->select(DB::raw("SUM(simpanans.nominal_transaksi * jenis_transaksis.tipe) as 'total'"))
                        ->whereIn('simpanans.jenis_transaksi',[1,2])
                        ->first();
       
        $total_uang = $total_uang->total;




        return view('monthly_report',[
            'monthly_reports' => $total_simpan,
            'total_saldo' => $total_saldo_sebulan,
            'avg_saldo' => $avg_saldo_sebulan,
            'selisih' => $selisih,
            'simpanan' => $transaksi_sebulan,
            'trx_bunga' => $transaksi_bunga,
            'nasabah_sekarang' => $total_nasabah_sekarang,
            'selisih_nasabah' => $selisih_nasabah,
            'total_uang' => $total_uang,
        ]);


    }


    public function yearly()
    {

        $first_month = date('Y-01-01');

        $first_month = date_create($first_month);

        $batas = 0;

        $months = [];

        $reports = [];

        $total_trx = [];

        $a = 0;

        while ($batas < 12) {

            $bulan_pertama = clone $first_month;
            
            $month = date_add($bulan_pertama,date_interval_create_from_date_string($a."Month"));

            $simpanan_per_bulan = DB::table('simpanans')
                                ->join('jenis_transaksis','simpanans.jenis_transaksi','=','jenis_transaksis.id')
                                ->select(DB::raw("COUNT(simpanans.id) AS 'total_trx', SUM(simpanans.nominal_transaksi * jenis_transaksis.tipe) AS 'total_tabungan'"))
                                ->whereIn('simpanans.jenis_transaksi',[1,2])
                                ->where(DB::raw("MONTH(simpanans.tanggal)"),$month->format('m'))
                                ->where(DB::raw("YEAR(simpanans.tanggal)"),$month->format('Y'))
                                ->first();

            $month = $month->format('F');
            array_push($total_trx,$simpanan_per_bulan->total_trx);
            array_push($months,$month);
            array_push($reports,$simpanan_per_bulan);

            $batas++;
            $a++;

        }

        $total_saldo_setahun = DB::table('simpanans')
                                ->join('jenis_transaksis','simpanans.jenis_transaksi','=','jenis_transaksis.id')
                                ->select(DB::raw("SUM(simpanans.nominal_transaksi * jenis_transaksis.tipe) AS 'total', AVG(simpanans.nominal_transaksi * jenis_transaksis.tipe) AS 'avg_total'"))
                                ->whereIn('simpanans.jenis_transaksi',[1,2])
                                ->where(DB::raw("YEAR(simpanans.tanggal)"),$first_month->format('Y'))
                                ->first();


        $avg_total_setahun = $total_saldo_setahun->avg_total;

        $total_saldo_setahun = $total_saldo_setahun->total;



        $haha = clone $first_month;

        date_sub($haha,date_interval_create_from_date_string("1 Year"));
        

        $total_tahun_kemarin = DB::table('simpanans')
                                ->select(DB::raw("COUNT(simpanans.id) AS total"))
                                ->whereIn('simpanans.jenis_transaksi',[1,2])
                                ->where(DB::raw("YEAR(simpanans.tanggal)"),$haha->format('Y'))
                                ->first();

        $total_tahun_kemarin = $total_tahun_kemarin->total;


        $tabungan_setahun = DB::table('simpanans')
                            ->join('anggotas','simpanans.anggota_id','=','anggotas.id')
                            ->join('users','simpanans.id_user','=','users.id')
                            ->join('jenis_transaksis','simpanans.jenis_transaksi','=','jenis_transaksis.id')
                            ->whereIn('simpanans.jenis_transaksi',[1,2])
                            ->where(DB::raw("YEAR(simpanans.tanggal)"),$first_month->format('Y'))
                            ->get();

        $total_trx = array_sum($total_trx);

        $selisih = $total_trx - $total_tahun_kemarin;


        
        $total_nasabah_sekarang = DB::table('anggotas')
                            ->select(DB::raw("COUNT(anggotas.id) AS 'total'"))
                            ->where(DB::raw("YEAR('created_at')"),$first_month->format('Y'))
                            ->first();

        $total_nasabah_kemarin = DB::table('anggotas')
                                ->select(DB::raw("COUNT(anggotas.id) AS 'total'"))
                                ->where(DB::raw("YEAR('created_at')"),$haha->format('Y'))
                                ->first();


        $total_nasabah_sekarang = $total_nasabah_sekarang->total;
        $total_nasabah_kemarin = $total_nasabah_kemarin->total;


        $selisih_nasabah = $total_nasabah_sekarang - $total_nasabah_kemarin;

        $total_uang = DB::table('simpanans')
                        ->join('jenis_transaksis','simpanans.jenis_transaksi','=','jenis_transaksis.id')
                        ->select(DB::raw("SUM(simpanans.nominal_transaksi * jenis_transaksis.tipe) as 'total'"))
                        ->whereIn('simpanans.jenis_transaksi',[1,2])
                        ->first();
       
        $total_uang = $total_uang->total;



        return view('yearly_report',[
            'months' => $months,
            'reports' => $reports,
            'avg_total' => $avg_total_setahun,
            'total_saldo' => $total_saldo_setahun,
            'selisih' => $selisih,
            'simpanan' => $tabungan_setahun,
            'nasabah_sekarang' => $total_nasabah_sekarang,
            'selisih_nasabah' => $selisih_nasabah,
            'total_uang' => $total_uang,

        ]);



    }







}
