<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Anggota extends Model
{
    
    protected $fillable = [
    'no_anggota',
    'nama',
    'alamat',
    'telepon',
    'noktp',
    'kelamin',
    'status_aktif',
    'user_id',
    ];

    public function transaksi()
    {
        return $this->hasmany('App\Simpanan');
    }



}


