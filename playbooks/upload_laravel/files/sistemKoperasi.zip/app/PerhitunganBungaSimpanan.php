<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PerhitunganBungaSimpanan extends Model
{
    protected $fillable = [
    'trx_bulan',
    'trx_tahun',
    'tanggal_proses',
    'persentase_bunga',
    'id_user',
    ];
}
