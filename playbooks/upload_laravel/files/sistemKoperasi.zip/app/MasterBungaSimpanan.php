<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MasterBungaSimpanan extends Model
{
    protected $fillable = [
    'persentase',
    'tanggal_mulai_berlaku',
    ];
}
